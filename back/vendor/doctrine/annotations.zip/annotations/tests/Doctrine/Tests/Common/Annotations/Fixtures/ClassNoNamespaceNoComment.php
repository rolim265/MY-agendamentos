<?php

use Doctrine\Tests\Common\Annotations\Fixtures\AnnotationTargetClass;

class Doctrine_Tests_Common_Annotations_Fixtures_ClassNoNamespaceNoComment
{
}
