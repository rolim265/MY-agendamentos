<?php

namespace Doctrine\Tests\Common\Annotations\Fixtures;

/**
 * @please-do-not-parse-me
 * @AlsoDoNot\Parse-me
 */
class ClassWithInvalidAnnotationContainingDashes
{
}
