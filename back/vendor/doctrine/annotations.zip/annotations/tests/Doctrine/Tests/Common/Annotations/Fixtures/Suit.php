<?php

declare(strict_types=1);

namespace Doctrine\Tests\Common\Annotations\Fixtures;

enum Suit
{
    case Hearts;
    case Diamonds;
    case Clubs;
    case Spades;
}
