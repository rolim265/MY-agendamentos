<?php

namespace Doctrine\Tests\Common\Annotations\Fixtures\Annotation;

class Param
{
}
