<?php

namespace Doctrine\Tests\Common\Annotations\Fixtures;

class ClassWithConstants
{
    public const SOME_VALUE  = 'ClassWithConstants.SOME_VALUE';
    public const SOME_KEY    = 'ClassWithConstants.SOME_KEY';
    public const OTHER_KEY_  = 'ClassWithConstants.OTHER_KEY_';
    public const OTHER_KEY_2 = 'ClassWithConstants.OTHER_KEY_2';
}
