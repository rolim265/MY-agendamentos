<?php

namespace {

    use Doctrine\Tests\Common\Annotations\Fixtures\Annotation\Route;
    use Doctrine\Tests\Common\Annotations\Fixtures\Annotation\Secure;

    class GlobalNamespacesPerFileWithClassAsFirst
    {
    }
}

namespace {

    use Doctrine\Tests\Common\Annotations\Fixtures\Annotation\Template;

}
