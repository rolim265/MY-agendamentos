<?php

namespace Doctrine\Tests\Common\Annotations\Fixtures\Traits;

trait EmptyTrait
{
}
