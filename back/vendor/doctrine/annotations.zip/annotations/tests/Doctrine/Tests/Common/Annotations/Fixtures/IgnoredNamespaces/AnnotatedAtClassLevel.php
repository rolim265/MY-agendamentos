<?php

namespace Doctrine\Tests\Common\Annotations\Fixtures\IgnoredNamespaces;

/**
 * @SomeClassAnnotationNamespace\Subnamespace\Name
 */
class AnnotatedAtClassLevel
{
}
