<?php

namespace Doctrine\Tests\Common\Annotations\Fixtures;

/**
 * @codingStandardsIgnoreStart
 * @codingStandardsIgnoreEnd
 */
class ClassWithPHPCodeSnifferAnnotation
{
}
