<?php

namespace Doctrine\Tests\Common\Annotations\Fixtures;

interface InterfaceWithConstants
{
    public const SOME_VALUE = 'InterfaceWithConstants.SOME_VALUE';
    public const SOME_KEY   = 'InterfaceWithConstants.SOME_KEY';
}
