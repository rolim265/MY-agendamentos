<?php

namespace Doctrine\Tests\Common\Annotations;

/** @Annotation */
class True
{
}

/** @Annotation */
class False
{
}

/** @Annotation */
class Null
{
}
