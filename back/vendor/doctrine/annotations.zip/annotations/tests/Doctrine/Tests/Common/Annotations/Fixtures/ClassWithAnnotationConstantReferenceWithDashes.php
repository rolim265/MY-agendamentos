<?php

namespace Doctrine\Tests\Common\Annotations\Fixtures;

use Doctrine\Tests\Common\Annotations\Fixtures\Annotation\Route;

/** @Route(@AValid-constant::REFERENCE) */
class ClassWithAnnotationConstantReferenceWithDashes
{
}
