<?php

namespace ClassLoaderTest;

class ClassD
{
}
