<?php

namespace Doctrine\Tests\Common\Proxy;

readonly class ReadOnlyClass
{
}
