<?php

namespace Doctrine\Tests\Common\Proxy;

abstract class AbstractClass
{
}
