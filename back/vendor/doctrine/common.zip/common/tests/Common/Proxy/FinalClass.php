<?php

namespace Doctrine\Tests\Common\Proxy;

final class FinalClass
{
}
