<?php

namespace Doctrine\Tests\Common\Proxy;

/**
 * PHP 7.1 void return type.
 */
class VoidReturnTypeClass
{
    public function returnsVoid() : void
    {
    }
}
