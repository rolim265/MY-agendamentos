<?php

namespace Doctrine\Tests\Common\Proxy;

/**
 * Test asset class
 */
class CallableTypeHintClass
{
    public function call(callable $foo)
    {
    }
}
