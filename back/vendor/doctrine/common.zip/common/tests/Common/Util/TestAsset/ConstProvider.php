<?php

declare(strict_types=1);

namespace Doctrine\Tests\Common\Util\TestAsset;

class ConstProvider
{
    public const FOO = ['foo'];
    public const FOO_SCALAR = 'foo';
}
